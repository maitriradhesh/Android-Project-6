package com.example.homework6;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;

public class AddContactActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);

        EditText nameEditText = findViewById(R.id.name);
        EditText phoneEditText = findViewById(R.id.phone);
        EditText emailEditText = findViewById(R.id.email);
        Button submitContactButton = findViewById(R.id.submitContact);

        submitContactButton.setOnClickListener(v -> {
            Intent resultIntent = new Intent();
            resultIntent.putExtra("name", nameEditText.getText().toString());
            resultIntent.putExtra("phone", phoneEditText.getText().toString());
            resultIntent.putExtra("email", emailEditText.getText().toString());
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}